import tkinter as tk
import random

class BouncingWindow:
    def __init__(self):
        self.root = tk.Tk()
        self.root.geometry("200x200")  # Size of the window
        self.root.overrideredirect(True)  # Remove title bar and borders
        self.root.wm_attributes("-topmost", True)  # Keep the window on top
        self.root.wm_attributes("-alpha", 0.8)  # Set transparency (0.0 to 1.0)

        # Make the window background color the same as the screen
        self.root.configure(bg='white')
        self.canvas = tk.Canvas(self.root, width=200, height=200, bg='white', highlightthickness=0)
        self.canvas.pack()

        self.angle = 0  # Rotation angle
        self.speed_x = 5 * random.choice([-1, 1])  # Random horizontal speed
        self.speed_y = 5 * random.choice([-1, 1])  # Random vertical speed

        # Draw the key shape
        self.draw_key()

        self.update_position()
        self.root.mainloop()

    def draw_key(self):
        # Draw a simple key shape using polygons and rectangles
        self.canvas.delete("all")  # Clear the canvas before drawing

        # Key stem
        self.canvas.create_rectangle(80, 60, 120, 140, fill='gold', outline='black')
        # Key head
        self.canvas.create_oval(70, 40, 130, 100, fill='gold', outline='black')
        # Key teeth
        self.canvas.create_rectangle(100, 140, 120, 160, fill='gold', outline='black')
        self.canvas.create_rectangle(80, 140, 100, 160, fill='gold', outline='black')

    def update_position(self):
        # Update the position of the window
        current_x = self.root.winfo_x()
        current_y = self.root.winfo_y()

        # Move the window
        self.root.geometry(f"+{current_x + self.speed_x}+{current_y + self.speed_y}")

        # Get the current position
        new_x = self.root.winfo_x()
        new_y = self.root.winfo_y()

        # Bounce off the edges
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        if new_x <= 0 or new_x >= screen_width - 200:  # Bounce horizontally
            self.speed_x = -self.speed_x

        if new_y <= 0 or new_y >= screen_height - 200:  # Bounce vertically
            self.speed_y = -self.speed_y

        # Redraw the key
        self.draw_key()

        # Schedule the next position update
        self.root.after(30, self.update_position)

if __name__ == "__main__":
    BouncingWindow()
